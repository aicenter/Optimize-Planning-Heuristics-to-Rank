############
#	A 
############

using NeuroPlanner
using PDDL
using Flux
using SymbolicPlanners
using Test
using Random
using Mill
using PlanningDomains
using Setfield

function test_domain(domain, problem; test_plan = true)
	try 
		pddld = HyperExtractor(domain) 
		pddle = HyperExtractor(domain, problem) 
		state = initstate(domain, problem)
		ds = pddle(state)
		model = reflectinmodel(ds, d -> Dense(d, 4);fsm = Dict("" =>  d -> Dense(d,1)))

		if test_plan
			trajectory, plan = NeuroPlanner.sample_forward_trace(domain, problem, 20);
			ds = fminibatch(pddld, domain, problem, plan);
			dedu =  @set ds.x = deduplicate(model, ds.x)
			NeuroPlanner.loss(model, ds) ≈ NeuroPlanner.loss(model, dedu)
			return(true)
		else
			dedu =  deduplicate(model, ds)
			model(ds) ≈ model(dedu)
			return(true)
		end
	catch 
		return(false)
	end
end


fminibatch = NeuroPlanner.minibatchconstructor("lstar")

sdir(s...) = joinpath("../classical-domains/classical/",s...)
local_problems = readdir(sdir())
local_problems = filter(s -> isfile(sdir(s, "domain.pddl")), local_problems)
valid = valid = ["agricola-opt18", "agricola-sat18", "airport", "airport-adl", "assembly", "barman-opt11-strips", "barman-opt14-strips", "barman-sat11-strips", "barman-sat14-strips", "blocks", "blocks-3op", "briefcaseworld", "caldera-opt18", "caldera-sat18", "caldera-split-opt18", "caldera-split-sat18", "cavediving", "childsnack-opt14-strips", "childsnack-sat14-strips", "citycar-opt14-adl", "citycar-sat14-adl", "cybersec", "data-network-opt18", "data-network-sat18", "depot", "driverlog", "elevators-00-full", "elevators-00-strips", "elevators-opt08-strips", "elevators-opt11-strips", "elevators-sat08-strips", "elevators-sat11-strips", "ferry", "flashfill-sat18", "floortile-opt11-strips", "floortile-opt14-strips", "floortile-sat11-strips", "floortile-sat14-strips", "freecell", "ged-opt14-strips", "ged-sat14-strips", "grid", "gripper", "hanoi", "hiking-opt14-strips", "hiking-sat14-strips", "logistics00", "logistics98", "maintenance-opt14-adl", "maintenance-sat14-adl", "miconic", "miconic-fulladl", "miconic-simpleadl", "movie", "mprime", "mystery", "no-mprime", "no-mystery", "nomystery-opt11-strips", "nomystery-sat11-strips", "nurikabe-opt18", "nurikabe-sat18", "openstacks", "openstacks-opt08-adl", "openstacks-opt08-strips", "openstacks-opt11-strips", "openstacks-opt14-strips", "openstacks-sat08-adl", "openstacks-sat08-strips", "openstacks-sat11-strips", "openstacks-sat14-strips", "openstacks-strips", "optical-telegraphs", "organic-synthesis-opt18", "organic-synthesis-sat18", "organic-synthesis-split-opt18", "organic-synthesis-split-sat18", "parcprinter-08-strips", "parcprinter-opt11-strips", "parcprinter-sat11-strips", "parking-opt11-strips", "parking-opt14-strips", "parking-sat11-strips", "parking-sat14-strips", "pathways", "pathways-noneg", "pegsol-08-strips", "pegsol-opt11-strips", "pegsol-sat11-strips", "petri-net-alignment-opt18", "philosophers", "pipesworld-06", "pipesworld-notankage", "psr-large", "psr-middle", "psr-small", "rovers", "rovers-02", "satellite", "scanalyzer-08-strips", "scanalyzer-opt11-strips", "scanalyzer-sat11-strips", "schedule", "settlers", "settlers-opt18", "settlers-sat18", "snake-opt18", "snake-sat18", "tetris-opt14-strips", "tetris-sat14-strips", "thoughtful-sat14-strips", "tidybot-opt11-strips", "tidybot-opt14-strips", "tidybot-sat11-strips", "tpp", "transport-opt08-strips", "transport-opt11-strips", "transport-opt14-strips", "transport-sat08-strips", "transport-sat11-strips", "transport-sat14-strips", "trucks", "trucks-strips", "tsp", "tyreworld", "visitall-opt11-strips", "visitall-opt14-strips", "visitall-sat11-strips", "visitall-sat14-strips", "woodworking-opt08-strips", "woodworking-opt11-strips", "woodworking-sat08-strips", "woodworking-sat11-strips", "zenotravel"]
valid = String[]
invalid = String[]
crashes_due_to_branching = String[]
failed_to_load = ["elevators-00-adl", "fridge", "pipesworld-tankage", "sokoban-opt08-strips", "sokoban-opt11-strips", "sokoban-sat08-strips", "sokoban-sat11-strips", "spider-opt18", "spider-sat18", "storage", "termes-opt18", "termes-sat18"]
for domain_name in local_problems
	domain_name ∈ valid && continue
	domain_name ∈ invalid && continue
	domain_name ∈ crashes_due_to_branching && continue
	problem_name = first(filter(s -> endswith(s, ".pddl") && s != "domain.pddl", readdir(sdir(domain_name))))
	println("testing on ",domain_name)
	domain, problem = try 
		domain = load_domain(sdir(domain_name, "domain.pddl"))
		problem = load_problem(sdir(domain_name, problem_name))
		domain, problem
	catch
		println("failed to load:", domain_name)
		push!(failed_to_load, domain_name)
		continue
	end
	if test_domain(domain, problem; test_plan = false)
		println((domain_name, problem_name),": succeeded")
		push!(valid, domain_name)
		@show valid
	else
		println((domain_name),": failed")
		push!(invalid, domain_name)
		@show invalid
	end
end



domain_list = list_domains(PlanningDomainsRepo)
valid = ["63-scanalyzer", "83-driverlog", "99-miconic", "17-zenotravel", "12-miconic", "22-ged", "19-tpp", "13-transport", "11-transport", "25-barman", "9-pegsol", "51-transport", "40-rovers", "102-no-mystery", "27-thoughtful", "56-tetris", "62-grid", "72-pegsol", "115-citycar", "84-barman", "67-depot", "49-rovers", "54-hiking", "118-transport", "57-transport", "112-blocks", "113-no-mprime", "61-airport", "91-scanalyzer", "82-scanalyzer", "119-gripper", "94-trucks", "110-assembly", "77-visitall", "52-ged", "121-tyreworld", "126-ferry", "127-blocks-3op", "107-parking", "117-citycar", "81-parking", "88-pegsol", "120-maintenance", "114-miconic", "6-transport", "123-briefcaseworld", "124-hanoi", "129-logistics00-reduced", "28-elevators", "26-cavediving", "30-freecell", "33-satellite", "128-blocks-reduced", "58-elevators", "23-visitall", "29-freecell", "46-parking", "20-floortile", "53-nomystery", "69-tidybot", "38-logistics", "106-philosophers", "89-hiking", "71-visitall", "18-barman", "74-floortile", "92-optical-telegraphs", "50-visitall", "37-elevators", "43-logistics", "95-elevators", "93-elevators", "24-elevators", "34-floortile", "10-floortile", "36-nomystery", "105-tidybot", "136-organic-synthesis-split", "133-data-network", "145-data-network", "148-organic-synthesis-split", "68-mystery", "101-mprime", "75-openstacks", "15-schedule", "78-woodworking", "90-pipesworld-notankage", "100-airport", "45-pathways-noneg", "98-pathways", "97-pipesworld", "14-pipesworld-tankage", "79-openstacks", "111-woodworking", "31-openstacks", "55-woodworking", "85-parcprinter", "116-childsnack", "48-psr-middle", "76-openstacks", "73-woodworking", "41-psr-large", "104-openstacks", "66-openstacks", "42-parcprinter", "108-parcprinter", "146-nurikabe", "135-nurikabe", "144-caldera-split", "132-caldera-split", "131-caldera", "143-caldera", "59-openstacks", "65-openstacks", "87-barman"]
invalid = ["16-trucks", "39-tetris", "103-elevators", "44-movie", "60-psr-small", "122-tsp", "70-childsnack", "64-openstacks", "138-snake", "150-snake", "142-agricola", "130-agricola", "141-petri-net-alignment"]
crashes_due_to_branching = ["32-satellite", "47-maintenance", "134-organic-synthesis", "80-cybersec"]
for (i, domain_name) in enumerate(domain_list)
	domain_name ∈ valid && continue
	domain_name ∈ invalid && continue
	domain_name ∈ crashes_due_to_branching && continue
	problem_name = first(list_problems(PlanningDomainsRepo, domain_name))
	println("testing on ",(i, domain_name))
	domain, problem = try 
		domain = load_domain(PlanningDomainsRepo, domain_name)
		problem = load_problem(PlanningDomainsRepo,domain_name, problem_name)
		domain, problem
	catch
		println("failed to load:", domain_name)
		continue
	end
	if test_domain(domain, problem)
		println((domain_name, problem_name),": succeeded")
		push!(valid, domain_name)
		@show valid
	else
		println((domain_name),": failed")
		push!(invalid, domain_name)
		@show invalid
	end
end



ipcyear = "ipc-2014"
domain_list = filter(s -> endswith(s,"satisficing"), list_domains(IPCInstancesRepo,ipcyear))
domain_list = filter(s -> contains(s,"sequential"), domain_list)
valid = []
for domain_name in domain_list
	domain = try 
		load_domain(IPCInstancesRepo,ipcyear, domain_name)
	catch
		println("failed to load:", domain_name)
		continue
	end
	problem_name = first(list_problems(IPCInstancesRepo, ipcyear, domain_name))
	problem = load_problem(IPCInstancesRepo, ipcyear,domain_name, problem_name)
	if test_domain(domain, problem)
		println((domain_name, problem_name),": succeeded")
		push!(valid, (domain_name,ipcyear, problem_name))
	else
		println((domain_name),": failed")
		@show (domain_name)
	end
end
valid = ["barman-sequential-satisficing", "hiking-sequential-satisficing", 
		"maintenance-sequential-satisficing", "parking-sequential-satisficing", 
		"tetris-sequential-satisficing", "thoughtful-sequential-satisficing", 
		"transport-sequential-satisficing"]


valid = ["agricola-opt18", "agricola-sat18", "airport-adl", "assembly", "barman-opt11-strips", "barman-opt14-strips", "barman-sat11-strips", "barman-sat14-strips", "blocks", "blocks-3op", "briefcaseworld", "caldera-opt18", "caldera-sat18", "caldera-split-opt18", "caldera-split-sat18", "cavediving", "childsnack-opt14-strips", "childsnack-sat14-strips", "citycar-opt14-adl", "citycar-sat14-adl", "data-network-opt18", "data-network-sat18", "depot", "driverlog", "elevators-00-full", "elevators-00-strips", "elevators-opt11-strips", "elevators-sat11-strips", "ferry", "floortile-opt11-strips", "floortile-opt14-strips", "floortile-sat11-strips", "floortile-sat14-strips", "freecell", "ged-opt14-strips", "ged-sat14-strips", "grid", "gripper", "hanoi", "hiking-opt14-strips", "hiking-sat14-strips", "logistics00", "logistics98", "maintenance-opt14-adl", "maintenance-sat14-adl", "miconic", "miconic-fulladl", "miconic-simpleadl", "movie", "mprime", "mystery", "no-mprime", "no-mystery", "nomystery-opt11-strips", "nomystery-sat11-strips", "nurikabe-opt18", "nurikabe-sat18", "openstacks", "optical-telegraphs", "parking-opt11-strips", "parking-opt14-strips", "parking-sat11-strips", "parking-sat14-strips", "pegsol-opt11-strips", "pegsol-sat11-strips", "philosophers", "pipesworld-06", "pipesworld-notankage", "psr-large", "psr-middle", "rovers", "rovers-02", "satellite", "scanalyzer-opt11-strips", "scanalyzer-sat11-strips", "schedule", "settlers", "settlers-opt18", "settlers-sat18", "snake-opt18", "snake-sat18", "tetris-opt14-strips", "tetris-sat14-strips", "thoughtful-sat14-strips", "tidybot-opt11-strips", "tidybot-opt14-strips", "tidybot-sat11-strips", "tpp", "transport-opt11-strips", "transport-opt14-strips", "transport-sat11-strips", "transport-sat14-strips", "trucks", "tsp", "tyreworld", "visitall-opt11-strips", "visitall-opt14-strips", "visitall-sat11-strips", "visitall-sat14-strips", "woodworking-opt11-strips", "woodworking-sat11-strips", "zenotravel"]
map(valid) do domain_name 
	problem_names = filter(s -> endswith(s, ".pddl") && s != "domain.pddl", readdir(sdir(domain_name)))
	(;domain_name, problem_instances=length(problem_names))
end |> DataFrame



# let's test the case where 
sdir(s...) = joinpath("../classical-domains/classical/",s...)
local_problems = readdir(sdir())
local_problems = filter(s -> !isfile(sdir(s, "domain.pddl")), local_problems)
local_problems = setdiff(local_problems, [".DS_Store"])
foreach(local_problems) do domain_name
	dfiles = filter(s -> contains(lowercase(s), "domain"), readdir(sdir(domain_name)))
	isempty(dfiles) && return((;domain_name, d = 0, problems = 0))
	d = map(dfiles) do s 
		# load_domain(sdir(domain_name, s))
		open(read, sdir(domain_name,dfiles[1]), "r") |> hash
	end |> unique
	if !isfile(sdir(domain_name, "domain.pddl"))
		cp(sdir(domain_name, first(dfiles)), sdir(domain_name, "domain.pddl")) 
	end
	filter!(s -> s != "domain.pddl", dfiles)
	foreach(s -> rm(sdir(domain_name,s)), dfiles)
end

