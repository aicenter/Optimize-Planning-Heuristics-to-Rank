# NeuroPlanner

This repository contains an implementation of HGNN and its variant used for experiments on general domains encoded in pddl. The experiments used julia version 1.9.

The main experiment is located in the file `scripts/supervised.jl`.
To repeat the experiments, go to the directory `scripts.`
First, you need to recreate environment with experiments. 
```
julia --project=. -e "using Pkg;Pkg.instantiate()"
```

The experiments were run on cluster with slurm package manager. The script that submitted jobs is in file `scrits/submit.sh`
alternatively, you can run it manually as 

```
for seed in 1 2 3 ; do 
	for glayers in 1 2 3; do 
		for d in 4 8 16 ; do 
			for residual in none linear ; do
				for loss in lstar lgbfs lrt l2 bellman  ; do
					for arch in hgnn ; do
						for p in spanner blocks ferry npuzzle elevators_00; do						
							julia --project=. supervised.jl $p $arch $loss --graph-layers $glayers --dense-dim $d --residual $residual --seed $seed
						done
					done
				done
				for p in spanner blocks ferry npuzzle elevators_00; do						
					julia --project=. supervised.jl $p $arch $loss --graph-layers $glayers --dense-dim $d --residual $residual --seed $seed
				done
			done
		done
	done
done
```

To create the tables for the paper and for the supplementary (general PDDL domains) run
```
julia --project=. show.jl
```
The tables are by default printed to the terminal for humans. If you want to print them for Latex, uncomment `backend = Val(:latex)` on line 225 in `scripts/show.jl`. File with raw results is stored in `scripts/super/results.csv`