module NeuroPlanner

using PDDL
using Julog
using Flux
using OneHotArrays
using Statistics
using SymbolicPlanners
using StatsBase
using Mill
using Setfield
using MLUtils
using DataStructures
using HierarchicalUtils
using ChainRulesCore

"""
initproblem(ex, problem; add_goal = true)

Specialize extractor for the given problem instance and return init state 
"""
function initproblem(ex, problem; add_goal = true)
	ex = specialize(ex, problem)
	pddle = add_goal ? add_goalstate(ex, problem) : ex
	pddle, initstate(ex.domain, problem)
end
export initproblem


include("relational/knowledge_base.jl")
include("relational/knowledge_model.jl")
include("relational/deduplication.jl")
include("relational/dedu_matrix.jl")
export KBEntry, KnowledgeBase, append, deduplicate

include("levin_asnet/extractor.jl")
include("levin_asnet/loss.jl")
include("levin_asnet/bfs_planner.jl")
export LevinASNet, BFSPlanner

include("hgnn/extractor.jl")
export HGNNLite, HGNN

include("losses.jl")
export L₂MiniBatch, LₛMiniBatch, LRTMiniBatch, LgbfsMiniBatch

export BackwardSampler
include("heuristic.jl")
export NeuroHeuristic

MLUtils.batch(xs::AbstractVector{<:AbstractMillNode}) = reduce(catobs, xs)
end
