for seed in 1 2 3 ; do 
	for glayers in 1 2 3; do 
		for d in 4 8 16 ; do 
			for residual in none linear ; do
				for loss in lstar lgbfs lrt l2 bellman  ; do
					for arch in hgnn ; do
						for p in spanner blocks ferry npuzzle elevators_00; do						
							sbatch -D $PWD slurm.sh $p $d $glayers $residual $loss $arch $seed
						done
					done
				done
				for p in spanner blocks ferry npuzzle elevators_00; do						
					sbatch -D $PWD slurm.sh $p $d $glayers $residual levinloss levinasnet $seed
				done
			done
		done
	done
done